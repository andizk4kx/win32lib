Note:
The xControls library imports all the other ew
include files so all of them should be in the
main Euphoria include folder.

Look under the help folder for "xControl.htm"
for details on the controls.

Look under the examples folder for some already
working code.

Don Phillips...

Changes:
-- Modified Pic Menu library to have built in support for icons
-- Fixed positional bugs with Geometry with Tab and Group controls
-- Fixed bug with '&' character in quotes added synUseColor(): Greg Haberek
--
