================================================
EuGrid:	A Grid Control for Euphoria and Win32lib
================================================
Version:	1.3.4
Date:	17th March 2007
Author:	Phil Russell
================================================
Description:

EuGrid is a datagrid control for MS Windows, written entirely in the Euphoria language and designed to be used
with the win32lib windows programming library. It allows data to be displayed and edited in a spreadsheet-like
format. It is intended to be useful for developing applications where two-dimensional 'record' data needs to be
displayed e.g. in database applications.

================================================
Changes for release 1.3.4
Removed dependency on eugrid_mem.e to allow compatibility with win32lib 0.7.*
Bugfix: fixed flicker when dialog box invoked from grid per Jonas Temple
New functions EGW_IsRowVisible and EGW_GetCurrentCellValue by Jonas Temple
================================================
Changes for release 1.3.3
Bugfix: for incorrect bitmap handle processing in EGW_SetCellProperty
Bugfix: for GDI memory leak in EGW_DrawBitmap
Some improvements to the documentation 
(thanks to Craig Welch for the above)
Bugfix: reset current row correctly when grid is cleared (thanks to Tony Steward)
================================================
Changes for release 1.3.2:

New messages EGW_KEYDOWN, EGW_KEYUP and EGW_KEYCHAR to allow for trapping
e.g. CTRL-S messages per Andres Cabezas

================================================
Changes for release 1.3.1:

Bugfix: Menu positioning problem with different versions of win32lib
Bugfix: Incorrect row selection when selecting from last row per Andres Cabezas

================================================
Changes for release 1.3.0:

Multiple row selectiom
Default row header is now triangular and tracks current row
Trigger EGW_CELLCHANGE on EGW_SetCurrentCell (thanks to Matt Lewis)
EDB fixes included (thanks Matt!)
Dropdown list cell type (EGW_DROPDOWN)
Bitmaps can be displayed in row headers
Picture cell type (EGW_PICTURE) displays bitmaps
Selection buttons (currently just on static, edit, combo and dropdown cells)
New messages: EGW_RIGHTBUTTONDOWN, EGW_RIGHTBUTTONUP
New grid property EGW_BITMAP_ROP (raster op used for bitblt)
New grid property EGW_MOUSE_CLICK_POSITION ({x,y} of last click)

** the above probably not exhaustive **

================================================
Changes for release 1.2.0:

Add EGW_COL_DISABLED/EGW_CELL_DISABLED to column and cell properties
Add EGW_TEXT_DISABLED_COLOR to grid properties.
Allow change of cell type via EGW_CELL_TYPE.
Maximum characters, data type, number format and text
alignment can now be specified at cell level via: 
	EGW_CELL_MAXCHARS, EGW_CELL_DATATYPE, EGW_CELL_NUMFORMAT, EGW_CELL_ALIGN.

New radio button cell type EGW_RADIOBUTTON.
Combo cell dropdown list can be displayed/hidden using EGW_CELL_SHOW_LIST.
Fix bug in sort routine, allow custom sort routine via EGW_SORT_ROUTINE_ID / EGW_COL_SORT_ROUTINE_ID.
Bugfixes in EGW_LoadData per Jonas Temple and CK Lester.
Fix header resize bug per Mr Trick.
Fix multiline field formatting.
New include file eugrid_mem.e (copy of w32support.e) included to accommodate changes to win32lib.
EGW_MAX_CHECKBOX height limits size of checkboxes and radiobuttons when row height is increased.
Fix to column scrolling (thanks to Andy Serpa)
Selected row is maintained when column resized (thanks to Matt Lewis).

================================================
Changes for release 1.1.1:

Add EGW_LEFTBUTTONDOWN & EGW_LEFTBUTTONUP messages (per Dan Moyer)
Fix current cell bug on reload of data (per Jonas Temple)

================================================
Changes for release 1.1.0:

New column types: Combobox and Checkbox columns
Edit columns can now be multiline
Column Sorting
Improved fix for xControls (no patched version required)
Improved drawing (less flicker)
Improved keyboard navigation
3D header effect can be turned on/off (EGW_ACTIVE_HEADERS)
Updated documentation

================================================
Zip File Contents:

**Required files -> include directory
eugrid.ew		The EuGrid include file

**Documentation and sample programs
eugrid.htm		EuGrid documentation (updated)
keymsg.exw	***Demo of new 1.3.2 messages
noah.e		EDS database functions for noah.exw
noah.edb		EDS database for noah.exw
noah.exw		Example of EDS database application using EuGrid *UPDATED for v1.3.0*
readme.txt		This file
simple.exw	Example of simple EuGrid usage
style.exw		Example of EuGrid display styles *UPDATED for v1.3.0*
xctest.exw		Example of using EuGrid with xControls geometry manager

plus various sample bitmaps (mostly culled from win32lib demos)

================================================
Installation:

Please refer to the documentation in eugrid.htm

================================================
User Licence and Disclaimer:

Please refer to the documentation in eugrid.htm before using EuGrid
================================================