win32lib 0.50c++
win32lib with RichEdit, Find and Replace Dialog, ListView TreeView and ListBox Extensions
by Matt Lewis (matthewlewis@hotmail.com , http://members.xoom.com/matthewlewis )

win32lib 0.50c by David Cuny

DISCLAIMER:
  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, 
  INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY
  AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
  AUTHOR BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, 
  OR CONSEQUENTIAL DAMGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF 
  SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFIT; OR BUSINESS 
  INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN 
  CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) 
  ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF 
  THE POSSIBILITY OF SUCH DAMAGE. 

NEW!
*********************************************************************************************
-- addXpm, addEuBmp, addDIB
-- internal documentation up to date (I think)
*********************************************************************************************
-- WM_COMMAND bug fixed
-- ComboBoxEx
-- setFocus() works with tab items
-- makedoc.exw included (documentation is _slowly_ catching up)
*********************************************************************************************
-- FlatToolBar: default, hot and disabled images
*********************************************************************************************
-- Automatically resizes rebars on WM_SIZE
-- getClientRect() takes rebars into account
-- Page setup dialog
*********************************************************************************************
-- Tooltips (not emulated any more)
*********************************************************************************************
-- ReBar
*********************************************************************************************
-- Month Calendar
-- UpDown control
*********************************************************************************************
-- RichEdit!
-- Supports Find/Replace Common dialog
-- Added function to get parents of treeview items
*********************************************************************************************
-- Wrapped drag and drop!
-- You can now use icons with transparent sections
-- Fixed some bugs and made functions return consistent values (win32lib indices vs handles)
*********************************************************************************************
-- Included listview and treeview wrappers into win32lib
-- Now use deleteItem() instead of deleteLVItem()/deleteTVItem
-- Use create() (or createEx() ) to create a listview/treeview
-- Wrapped TVN_SELCHANGED into onEvent!
*********************************************************************************************
--Wrapped most functions so programmer doesn't have to deal with the win32 API. 
--Item text now maintained by Eu code, rather that letting windows.
--Columns automatically sort when you click on column headers.
*********************************************************************************************

I've modified win32lib to be able to handle the RichEdit, ListView and TreeView controls, and to allow multiple selections with listboxes.  I haven't wrapped everything, but almost all of the messages and their constants have been added.  Right now, you can create, populate and get the selections from a listview and treeview.  See ListTreeView.exw.  In RichEdit.exw you'll see my RichEdit demo.  I've wrapped all of the code I added to win32lib with comments:

-- Begin Matt Lewis
..code
-- End Matt Lewis

I've added 4 new classes to win32lib: RichEdit, ListView, TreeView and ImageList.  The ImageList class is where icons to be displayed for items are kept. Win32lib actually uses up to 3 different ImageLists for ListViews: one for large icons, one for small icons and one for state icons.  For TreeViews: one for normal icons and one for state icons.  The imagelists are shared by listviews and treeviews, and you don't need to worry about the implementation of them when using win32lib.  You just use the addIcon() function, and use the value returned to assign icons to items in both listviews and treeviews.


To create a listview control, use the create (or createEx function) as normal, except rather than a caption, include a sequence of strings that will become the column headers.  Win32lib will automatically create the columns for you.

Image lists are automatically created, and all listviews share the same imagelist.  To add an icon, use:

addIcon( atom hIcon )

where hIcon is the handle to the icon.  addIcon() returns the id to use when adding items to a listview, which is accomplished using:

addLVItem(integer id, atom iIcon, sequence text )

id: id of the listview to add item
iIcon: id of the icon to use
text: sequence of strings that correspond to the text to display in each column of the item
addLVItem() returns the listview item id, which you should use to get text and to delete items.

To delete an item from a listview:
deleteItem( integer id, integer lParam )

id: id of the listview
lParam: id of the listview item (if lParam is -1, all items are deleted)

When creating a ListView, here are some important style flags:

LVS_ALIGNLEFT
LVS_ALIGNTOP
LVS_AUTOARRANGE
LVS_EDITLABELS
LVS_ICON
LVS_LIST
LVS_NOCOLUMNHEADER
LVS_NOLABELWRAP
LVS_NOSORTHEADER
LVS_OWNERDRAWFIXED
LVS_REPORT
LVS_SHAREIMAGELISTS
LVS_SHOWSELALWAYS
LVS_SINGLESEL
LVS_SMALLICON
LVS_SORTASCENDING
LVS_SORTDESCENDING



TreeViews are similar, but you don't have to worry about columns. When adding an item to a treeview, use the following function:

global function addTVItem( atom id, atom iImage, atom iSelectedImage,
                sequence text, atom iParent )

id: win32lib id of the treeview

iImage: icon id returned from addIcon().  This will be the normal icon for the item.

iSelectedImage: icon id returned from addIcon().  This will be the selected icon for the item.

text: string.  This will be the item text.

iParent:  If this is a child of another item, use the item id of the parent item, otherwise, iParent should be zero.

I've also made it easy to tell when the user selects an item within the treeview.  Within the onEvent procedure for the treeview, trap the event onTVSelect.  wParam will be the id of the old item selected, and lParam will be the new item.  See the TV.exw for an (annoying) example of this.


These are important treeview style flags:
TVS_HASBUTTONS
TVS_HASLINES
TVS_LINESATROOT
TVS_EDITLABELS
TVS_DISABLEDRAGDROP
TVS_SHOWSELALWAYS
TVS_RTLREADING
TVS_NOTOOLTIPS
TVS_CHECKBOXES
TVS_TRACKSELECT
TVS_SINGLEEXPAND
TVS_INFOTIP
TVS_FULLROWSELECT
TVS_NOSCROLL
TVS_NONEVENHEIGHT

*********************************************************************************************
DRAG AND DROP

I changed the drag and drop event (onDragAndDrop).  It now supplies 2 parameters to the event handler.  The first is an integer, that is either 0 if windows is dropping files (the dNd behavior win32lib already had), or the id of the control that is dropping files.  Currently, only listviews are set up to supply drag and drop data.  The second param is a sequence containing either the filename (from windows) or the indices of the items being dragged.

When using this with treeviews, you'll need to use the new function hitTestTV.  This function will tell you which item (if any) was the target of the drop.  It takes one param, the id of the treeview.  Take a look at demo.exw to see how this is done.

*********************************************************************************************
RichEdit

Create a richedit control just like you would with any other edit control (create()).  Richedit controls function simlilarly to other edit controls, with some changes:

When you change the font of a richedit, win32lib will either change the selection of text to the specified font, or it will change the default font, and new typing will be in the specified font.  There is a slight change to the usage of setFont(), however, since you can change the color of text.  Use setFont():

setFont( id, { color, faceName }, points, attributes )

To load [into] or save [from] a richedit control, there are two new routines:

global procedure putStream( integer id, integer flags, sequence streamin )
and
global function getStream( integer id, integer flags ) 

id: win32lib id of the control
flags: one of several values:
		StreamText		plain text
		StreamRich		rich text
		StreamSelection	replace contents of current selection
					otherwise, replace all
streamin: sequence of text to be placed in richedit control

getStream() returns a sequence containing the contents of the control

Use getText() to get the text of the current selection, and getIndex() to find the position of the cursor or the current selection.

setBullet( id )
This will make the current selection's paragraph format a bullet.

To set tab stops, use:
setTabs( id, tabs )
where tabs is a sequence of absolute values (in pixels, I think) of the positions of the tab stops.

You can change the indentation of text using setIndent():
global procedure setIndent( integer id, object start, object right, object offset )
If you do not wish to change one of these, pass a sequence as the parameter ( {} works fine ).  Otherwise, the values do the following:

start:
Indentation of the first line in the paragraph.

right:
Size of the right indentation, relative to the right margin.

offset:
Indentation of the second line and subsequent lines, relative to the starting indentation. The first line is indented if this member is negative, or outdented is this member is positive.

This doesn't seem to work as advertised, but I haven't been able to figure it out, so if anyone can fix it, please do.

Change the alignment of text using:
global procedure setAlignment( integer id, integer align )
The valid values for align are:
AlignLeft
AlignRight
AlignCenter

Find and Replace:

Call either:
getFindText( id )
or 
getReplaceText( id )

to call the respective dialog box.  This works differently than the file or font dialogs, in that it's modeless, and so will return control immediately to your code.  When the user clicks find or replace, win32lib will handle the action automatically.

*********************************************************************************************
MonthCalendar
(see MonthCalendar.exw)
Use class MonthCalendar to create the month calendar control.

getSelectedDate( id )
getSelectedDateRange( id )

These return the date in the format:
date = {year, month, day of week, day of month }
The range will be a sequence of 2 dates.

setSelectedDate( id, date )
date should be a sequence as above

setSelectedDateRange( id, range )
range should be a sequence of 2 dates

setMaxDateRange( id, max )
max should be the maximum number of days the user can select

setMonthColor( id, section, color )
section takes one of the following values:
 MCSC_BACKGROUND
 MCSC_TEXT
 MCSC_TITLEBK
 MCSC_TITLETEXT
 MCSC_MONTHBK
 MCSC_TRAILINGTEXT
color should be a 32-bit color value (see rgb() )

formatDate( date, format )
date is a sequence as above
format takes one of these values:
LongDate		Tuesday, August 1, 2000
MediumDate		1-Aug-00
ShortDate		8/1/00

*********************************************************************************************
UpDown control
(see UpDown.exw)

If you use UDS_ALIGNLEFT/RIGHT, you don't need to specify x, y or cx, cy parameters at creation time for the UpDown control.  

If you don't use UDS_AUTOBUDDY (which makes the control created just previous to the updown control it's buddy), you can use:

setBuddy( id, buddy )

To set the scroll range, use:

setScrollRange( id, min, max )
Min can be greater than max:  when the user clicks on the upper button, the value gets closer to the max, and vice versa for min.

The following window styles are used with up-down controls.

UDS_ALIGNLEFT	Positions the up-down control next to the left edge of the buddy window. The buddy window is moved to the right and its width decreased to accommodate the width of the up-down control.

UDS_ALIGNRIGHT	Positions the up-down control next to the right edge of the buddy window. The width of the buddy window is decreased to accommodate the width of the up-down control.

UDS_ARROWKEYS	Causes the up-down control to increment and decrement the position when the UP ARROW and DOWN ARROW keys are pressed.

UDS_AUTOBUDDY	Automatically selects the previous window in the Z order as the up-down control's buddy window.

UDS_HORZ	Causes the up-down control's arrows to point left and right instead of up and down.

UDS_NOTHOUSANDS	Does not insert a thousands separator between every three decimal digits. 

UDS_SETBUDDYINT	Causes the up-down control to set the text of the buddy window (using the WM_SETTEXT message) when the position changes. The text consists of the position formatted as a decimal or hexadecimal string.

UDS_WRAP	Causes the position to "wrap" if it is incremented or decremented beyond the ending or beginning of the range.

*********************************************************************************************
ReBar
(see ReBar.exw)

Rebars are similar to toolbars, but can do some fancier things.  You can put any sort of control into a rebar.  Here are the steps to using a rebar:

-- create the rebar
rebar = create( ReBar, "", owner, x, y, cx, cy, flags )

-- create a band for the rebar
band = create( ReBarBand, caption, rebar, 0, 0, cx, cy, flags )
[NOTE: to create the band on a new line within the rebar, use RBBS_BREAK ]

-- add controls to the bands.  Controls should be children of the rebar.
combo = create( Combo, "", rebar, 0, 0, cx, cy, flags )
addToBand( combo, band )

A rebar can have multiple bands, which the user can resize and move around (depending on styles specified). 

*********************************************************************************************
Tooltips
(see Tooltips.exw)

These are used the same as before:

setHint( ) and setHintFont( )

Actually, you can use setFont() now.  Use tooltipControl as the id of the tooltip control (this changes all tooltips).  Changing the tooltip font can only be done after at least one tooltip is created.  This is because win32lib only creates the tooltip control when it's needed.

*********************************************************************************************
getPageSetup()

This function allows the user to select a page setup and printer.  I think.  I'm not really up on printing in windows, so I'm not sure how all these things need to be tracked, etc.  The function currently returns two sequences: the paper size and the left, top, right and bottom margins.  It also sets the printerDC to the printer that the user selected.  Again, I haven't tested that this does everything you need it to do (for instance, do I need to send any messages to the printer regarding paper size or margins?), so don't assume it does? :)

*********************************************************************************************
FlatToolBar
(see ToolBar.exw)
Create a FlatToolBar the same way you'd create a normal toolbar.  Buttons will be created differently, however.  The toolbar will create them, and so they won't have handles (so if you want to send a message to a button, you'll actually have to send it to the toolbar), but are manipulated through sending messages to the toolbar.  The 'x' param in create should be the index of the icons to use.  Use addIcon( { hDefault, hHot, hDisabled } ) to add icons for the toolbar (these are separate from icons used for listviews/treeviews).

To create a separator, use the class SepButton.

*********************************************************************************************
ComboBoxEx
(see ComboBoxEx.exw)
Create using ComboBoxEx class.  This control should function exactly like a combo, except that you need to add items differently, since it can display icons to the left of the text.  First, you need to add icons using addIcon.  These images are shared with those used by list and tree views.  When you add an item:

addItem( id, { "Item Text", nonselected icon id, selected icon id } )
