** NOTICE **

FRED's COMMENT (2016) - This is Wolfritz's old Win32Lib tutorial, 
with instructional code and demo programs' code modified to run 
under Euphoria 4 + Win32Lib. Place the Tutor2 folder in your 
Win32Lib folder and run file WinTutor.exw or WinTutor.exe. Many 
things that were a 'problem' for Wolfritz and needed special coding 
are now quite easy to do with new commands in Win32Lib. Even so, I 
have as far as possible NOT re-written Wolfritz's tutorial, because it
often provides insights into how the API actually works.

------

At the present time, with Win32lib version 0.55.1 to 0.57.9,
the required 'include' support files are:
win32lib.ew, compat01.ew, tk_maths.e, tk_mem.e,
tk_misc.e, tk_trim.e, and w32Keys.e

More advanced users can include their preferred Win32lib folder
using the EUINC environment variable, and comment-out the
*paranoid* code call in WinTutor.exw >> ( line 35 )
  
-- BUGS -- aside from my own  ;-)

Win32lib versions 0.55.1, and 0.55.5 won't do onDestroy[],
so I've only used it in meminfo.exw.

Win32lib version 0.57.9 can't do setHint().

Win32libs 0.55.1 to 0.55.10 have 'difficulty' with setFocus(),
so I've mentioned a temporary patch in Lesson 26.


 -- AND WinTutor.exw is the name of the main program you should run. --

This will allow you to select a lesson from the list. Selecting the
[Open] button, or using the enter key, will open up the hi-lighted
HTML document about this lesson.
  ( if you're using Microsoft's Explorer, the F11 key is handy. )

Selecting the [Run an Example] button will give you an [Open] dialog
box. If there is only one example program to run, it's name will
already be in the file name box, so just select [Open] to run the
displayed program.

If there is a second example associated with this lesson, and it's a
program file, you'll have to select it from the list manually, first.
    ( .ew files are not programs, but 'include' files. )

The [Example] [View] menu item of WinTutor.exw will show you the
actual program's text source file.


..these programs assume that you have, at least, EUPHORIA 2.3.

..that you have some default file type associations set up for .html, .exw,
  and .txt files, to start up these file types automatically.
  ( set up through Windows Explorer, for example. )

Since win32lib.ew is currently being updated quite frequently, future
versions of this program will indicate the latest version of Win32lib.ew
that these examples will all work for. At the present time all these
programs work with version 0.57.5, and hopefully, beyond.


Wolfgang Fritz.  wolfritz@king.igs.net
Ad Rienks.       kwibus@zonnet.nl
Brian Broker.    bkb@cnw.com


