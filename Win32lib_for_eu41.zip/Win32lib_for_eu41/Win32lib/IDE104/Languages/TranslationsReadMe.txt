language files must be in a specific format. See English.lng for an example. Note that the last parameter of all messages (except Msg 10) is for MB_XXX values and Text/Hint entries do not have a 3rd parameter at all.

Do not use the actual MB_XXX name but the decimal value. To help you with determining the decimal value and to test your translation there is a program, ErrMsgTxt.exw in this folder.

There is a package in the Bleeding Edge section of the home page, Translators Toolkit, which has simple projects for testing translations of various windows in IDE. Please notify me of any field that is not large enough to accommodate your translation so we can work on those for the next release.

